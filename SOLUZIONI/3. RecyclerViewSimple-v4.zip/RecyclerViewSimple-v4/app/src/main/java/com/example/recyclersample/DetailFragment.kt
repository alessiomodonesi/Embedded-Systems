package com.example.recyclersample

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment

class DetailFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_detail, container, false)

        // Get the reference to the TextView
        val tv = view.findViewById<TextView>(R.id.tv)

        // Set the message in the TextView
        val flowerName = DetailFragmentArgs.fromBundle(requireArguments()).flower
        tv.text = getString(R.string.flower_message, flowerName)

        return view
    }
}
