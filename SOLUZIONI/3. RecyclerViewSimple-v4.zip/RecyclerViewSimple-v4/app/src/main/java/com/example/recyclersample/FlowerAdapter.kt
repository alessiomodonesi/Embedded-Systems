/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.recyclersample

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView

class FlowerAdapter(private val data: Datasource) :
    RecyclerView.Adapter<FlowerAdapter.FlowerViewHolder>() {

    private val onClickListener = View.OnClickListener { v ->
        val flower = (v as TextView).text.toString()

        val action = ListFragmentDirections
            .actionListFragmentToDetailFragment(flower)
        v.findNavController().navigate(action)
    }

    // Describes an item view and its place within the RecyclerView
    class FlowerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val flowerId: TextView = itemView.findViewById(R.id.flower_id)
        private val flowerTextView: TextView = itemView.findViewById(R.id.flower_text)
        private val flowerColor: TextView = itemView.findViewById(R.id.flower_color)

        fun bind(flower: Datasource.FlowerItem) {
            flowerId.text = flower.id.toString()
            flowerTextView.text = flower.name
            flowerColor.text = flower.color
        }
    }

    // Returns a new ViewHolder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FlowerViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.flower_item, parent, false)

        val tv: TextView = view.findViewById(R.id.flower_text)
        tv.setOnClickListener(onClickListener)

        return FlowerViewHolder(view)
    }

    // Returns size of data list
    override fun getItemCount(): Int {
        return data.getFlowerList().size
    }

    // Displays data at a certain position
    override fun onBindViewHolder(holder: FlowerViewHolder, position: Int) {
        val f = data.getFlowerList()[position]
        holder.bind(f)
    }
}
