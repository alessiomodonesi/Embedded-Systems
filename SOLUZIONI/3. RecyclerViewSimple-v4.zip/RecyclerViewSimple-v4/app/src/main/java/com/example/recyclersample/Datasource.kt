/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.recyclersample

import android.content.Context

class Datasource(private val context: Context) {
    // Number of flowers
    private val count = 25

    // The data repository: a mutable list of flower items
    private val items: MutableList<FlowerItem> = ArrayList()

    init {
        val flowerNames = context.resources.getStringArray(R.array.flower_array)
        val flowerColors = context.resources.getStringArray(R.array.flower_colors)

        // Add flowers to the repository
        var name: String
        var color: String
        for (i in 1..count) {
            name = if(i < flowerNames.size) flowerNames[i-1]
                   else context.resources.getString(R.string.flower_name_nth, i)
            color = if(i < flowerColors.size) flowerColors[i-1]
                    else context.resources.getString(R.string.flower_color_unknown)
            items.add(FlowerItem(i,name,color))
        }
    }

    /*fun getFlowerList(): Array<String> {

        // Return flower list from string resources
        return context.resources.getStringArray(R.array.flower_array)
    }*/
    fun getFlowerList(): Array<FlowerItem> {

        // Return flower list from string resources
        return items.toTypedArray()
    }

    data class FlowerItem(val id: Int, val name: String, val color: String)
}
