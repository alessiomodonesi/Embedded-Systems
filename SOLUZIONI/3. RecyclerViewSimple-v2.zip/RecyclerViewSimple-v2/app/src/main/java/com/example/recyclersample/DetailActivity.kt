package com.example.recyclersample

import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat

class DetailActivity : AppCompatActivity()
{
    // Tag for Log messages
    private val mTAG = this::class.simpleName

    // Called when the activity is first created
    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)

        // Enable edge-to-edge display on API level < 35
        WindowCompat.enableEdgeToEdge(window)

        // Display the layout
        setContentView(R.layout.activity_detail)

        // Get the reference to the TextView
        val tv : TextView = findViewById(R.id.tv)

        // Set the message in the TextView
        val flowerName = intent.getStringExtra(ARG_FLOWER_NAME)
        tv.text = getString(R.string.flower_message, flowerName)

        // Ensure that system bars remain visible regardless of the background color:
        // done via XML styling
    }

    override fun onDestroy()
    {
        super.onDestroy()
        Log.v(mTAG, "onDestroy() called")
    }

    companion object {
        // The activity argument representing a flower name
        const val ARG_FLOWER_NAME = "flower_name"
    }
}
