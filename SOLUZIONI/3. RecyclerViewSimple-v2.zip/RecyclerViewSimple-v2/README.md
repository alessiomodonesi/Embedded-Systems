RecyclerSimple
==============

Contains the finished code of Google's Simple RecyclerView sample app,
modified with an additional activity which is started by clicking on the
elements of the RecyclerView (i.e., on the names of flowers).
The original code can be found in the main branch of the
[views-widgets-samples](https://github.com/android/views-widgets-samples)
repository as of commit f22069a, inside the RecyclerViewSimple directory.

For an overview on RecyclerView and additional details about its use,
consult Google's
"[Create dynamic lists with RecyclerView](https://developer.android.com/guide/topics/ui/layout/recyclerview)"
guide.
