/*
 * Unit tests with Robolectric in a simulated Android environment.
 * References:
 * https://github.com/robolectric/robolectric
 * http://robolectric.org/javadoc/latest/org/robolectric/annotation/Config.html
 */
package com.example.android.simplecalctest

import android.os.Build
import android.widget.EditText
import org.junit.Assert.*
import org.junit.Before
import org.junit.FixMethodOrder
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.MethodSorters
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

// Run tests with the Robolectric test runner.
// Alternatively, it is now possible to use the AndroidX test runner
// in Robolectric tests: https://robolectric.org/androidx_test/
@RunWith(RobolectricTestRunner::class)
// Run tests on multiple API levels.
// Note: it is currently impossible to run tests on the full range of versions
// from O (API level 26) to BAKLAVA (API level 36)
// because of a memory leak in Robolectric that exhausts the Java memory heap
// after a certain number of tests
@Config(minSdk = Build.VERSION_CODES.Q, maxSdk = Build.VERSION_CODES.BAKLAVA)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
class MainActivityTest {
    private lateinit var activity: MainActivity
    private lateinit var operandOne: EditText

    @Before
    fun setUp() {
        activity = Robolectric.buildActivity(MainActivity::class.java)
                   .create().start().resume()
                   .get()

        operandOne = activity.findViewById(R.id.operand_one_edit_text)
    }

    @Test
    fun appName() {
        val hello = activity.resources.getString(R.string.app_name)
        assertEquals("SimpleCalcTest", hello)
    }

    @Test
    fun operandConversion1_int() {
        operandOne.setText("3")
        val d = activity.getOperand(operandOne)
        assertEquals(3.0, d, 0.0)
    }

    @Test
    fun operandConversion2_fp() {
        operandOne.setText("3.14")
        val d = activity.getOperand(operandOne)
        assertEquals(3.14, d, 0.0)
    }

    @Test
    fun operandConversion3_negative() {
        operandOne.setText("-428.96")
        val d = activity.getOperand(operandOne)
        assertEquals(-428.96, d, 0.0)
    }

    @Test(expected = NumberFormatException::class)
    fun operandConversion4_empty() {
        operandOne.setText("")
        activity.getOperand(operandOne)
    }
}
