/*
 * Unit tests with AndroidJUnit4 in a simulated Android environment.
 * References:
 * https://developer.android.com/reference/androidx/test/runner/AndroidJUnit4
 * https://developer.android.com/jetpack/androidx/releases/test
 * https://developer.android.com/guide/components/activities/testing
 */
package com.example.android.simplecalctest

import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.lifecycle.Lifecycle
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)    // will delegate to RobolectricTestRunner
// Since no minSdk or maxSdk are specified (see MainActivityTest.kt),
// tests will be run only against the latest Android version
class MainActivityTestX {
    private lateinit var scenario: ActivityScenario<MainActivity>

    @Before
    fun setUp() {
        scenario = ActivityScenario.launch(MainActivity::class.java)
    }

    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun addTwoNumbers() {
        scenario.moveToState(Lifecycle.State.RESUMED)
        scenario.onActivity { activity: MainActivity ->
            // never keep references obtained into your action
            // because the activity can be recreated at any time during state transitions
            val operandOne: EditText = activity.findViewById(R.id.operand_one_edit_text)
            val operandTwo: EditText = activity.findViewById(R.id.operand_two_edit_text)
            val operationResult: TextView = activity.findViewById(R.id.operation_result_text_view)
            val operationAdd: Button = activity.findViewById(R.id.operation_add_btn)

            operandOne.setText("1.0")
            operandTwo.setText("1.0")
            operationAdd.performClick()
            assertEquals("2.0", operationResult.text.toString())
        }
    }

    @Test
    fun divByZeroShowsError() {
        scenario.moveToState(Lifecycle.State.RESUMED)
        scenario.onActivity { activity: MainActivity ->
            val operandOne: EditText = activity.findViewById(R.id.operand_one_edit_text)
            val operandTwo: EditText = activity.findViewById(R.id.operand_two_edit_text)
            val operationResult: TextView = activity.findViewById(R.id.operation_result_text_view)
            val operationDiv: Button = activity.findViewById(R.id.operation_div_btn)

            operandOne.setText("32.0")
            operandTwo.setText("0.0")
            operationDiv.performClick()
            assertEquals(activity.getString(R.string.computationError),
                         operationResult.text.toString())
        }
    }

    @After
    fun cleanUp() {
        // ActivityScenario does not clean up device state automatically:
        // if close() is not called, the activity may be left running after the tests finish
        scenario.close()
    }
}
