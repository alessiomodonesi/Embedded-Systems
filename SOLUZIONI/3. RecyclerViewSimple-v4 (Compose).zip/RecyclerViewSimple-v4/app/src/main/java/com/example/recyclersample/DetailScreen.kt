/*
 * Copyright (C) 2020 The Android Open Source Project
 * Licensed under the Apache License, Version 2.0.
 */

package com.example.recyclersample

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.sp

/**
 * Screen that tells the user which flower they picked.
 *
 * Plays the role that `DetailFragment` played in the original View-based
 * implementation: show the message `"<Name> is a nice flower"` centered on
 * screen. Two things collapse in the Compose version:
 *
 * - **No fragment lifecycle.** `DetailFragment` had to inflate a layout in
 *   `onCreateView`, look up its `TextView` via `findViewById`, then call
 *   `setText(...)`. `DetailScreen` is just a function that describes the UI
 *   for a given `flowerName`; Compose runs it whenever that input changes.
 *
 * - **No Safe Args, no `Bundle`.** The fragment read its argument with
 *   `DetailFragmentArgs.fromBundle(requireArguments()).flower`. Here the
 *   flower name is passed as a plain Kotlin parameter — the caller
 *   (`RecyclerSampleApp`'s `NavHost`) is the one that extracts it from the
 *   navigation back-stack entry. This separation — one function describes
 *   the UI, another wires up navigation — is a common pattern in Compose.
 *
 * @param flowerName the name of the flower to mention in the message.
 * @param modifier caller-supplied modifier, applied to the root `Box`.
 */
@Composable
fun DetailScreen(
    flowerName: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = stringResource(id = R.string.flower_message, flowerName),
            fontSize = 24.sp
        )
    }
}
