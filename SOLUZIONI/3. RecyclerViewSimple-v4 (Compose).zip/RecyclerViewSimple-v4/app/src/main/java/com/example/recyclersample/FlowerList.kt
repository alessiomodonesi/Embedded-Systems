/*
 * Copyright (C) 2020 The Android Open Source Project
 * Licensed under the Apache License, Version 2.0.
 */

package com.example.recyclersample

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Scrollable list of flowers.
 *
 * Plays the role that the `RecyclerView` (configured with a `LinearLayoutManager`
 * and driven by `FlowerAdapter`) played in the original View-based implementation:
 * it lays out one item per flower vertically and recycles off-screen items as the
 * user scrolls. In Compose this is handled by `LazyColumn`, which composes only
 * the items currently visible on screen and reuses their slots when they leave.
 *
 * @param flowers the data to display, one row per element.
 * @param onFlowerClick invoked when the user taps a row's flower name; receives
 *   the clicked [Datasource.FlowerItem]. This is the Compose-idiomatic replacement
 *   for the `View.OnClickListener` the adapter attached to each item view.
 * @param modifier caller-supplied modifier, applied to the underlying `LazyColumn`.
 */
@Composable
fun FlowerList(
    flowers: List<Datasource.FlowerItem>,
    onFlowerClick: (Datasource.FlowerItem) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(modifier = modifier.fillMaxSize()) {
        items(flowers, key = { it.id }) { flower ->
            FlowerRow(flower = flower, onClick = { onFlowerClick(flower) })
        }
    }
}

/**
 * Single row describing one flower: a large id box on the left, and the flower's
 * name and color stacked on the right.
 *
 * Corresponds to the `flower_item.xml` layout plus the `FlowerAdapter.FlowerViewHolder`
 * from the original View-based implementation. In the old code the layout defined
 * the structure, and the ViewHolder's `bind` method filled in the data for a given
 * item. Here both responsibilities collapse into this one composable: the layout
 * is expressed directly by the `Row`/`Column`/`Text` calls, and data binding happens
 * just by passing a [Datasource.FlowerItem] as a parameter — Compose re-invokes the
 * function whenever the inputs change.
 *
 * Note that there is no explicit "holder" object in Compose: `LazyColumn` reuses
 * composition slots internally, but user code never sees or manages them.
 *
 * @param flower the data to display in this row.
 * @param onClick invoked when the user taps the flower's name (only the name is
 *   clickable, matching the original adapter's behavior).
 */
@Composable
private fun FlowerRow(
    flower: Datasource.FlowerItem,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Flower id box — mirrors the 80dp-wide accent-colored TextView.
        // Text color is intentionally not set, so it inherits from the
        // ambient Material theme just like the original XML TextView did
        // (which had no android:textColor attribute).
        Text(
            text = flower.id.toString(),
            fontSize = 50.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .width(80.dp)
                .background(colorResource(id = R.color.colorAccent))
        )
        Column(
            // weight(1f) gives this Column all the horizontal space
            // remaining after the fixed-width id box — the idiomatic
            // Row counterpart of XML's layout_weight.
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.Center
        ) {
            // Only the flower name is clickable, matching the original behavior
            Text(
                text = flower.name,
                fontSize = 32.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onClick)
            )
            Text(text = flower.color)
        }
    }
}
