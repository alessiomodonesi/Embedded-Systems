/*
 * Copyright (C) 2020 The Android Open Source Project
 * Licensed under the Apache License, Version 2.0.
 */

package com.example.recyclersample

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.view.WindowCompat
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

object Routes {
    const val LIST = "list"
    const val DETAIL = "detail/{flower}"
    fun detail(flower: String) = "detail/$flower"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Enable edge-to-edge display
        WindowCompat.enableEdgeToEdge(window)

        setContent {
            val colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()
            MaterialTheme(colorScheme = colorScheme) {
                // Scaffold provides the standard Material 3 container: it paints the
                // theme's background color, respects the status/navigation bar
                // insets via `contentWindowInsets`, and hands out the corresponding
                // `innerPadding` to apply to content so nothing is drawn under
                // the system bars
                Scaffold { innerPadding ->
                    RecyclerSampleApp(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

/**
 * Root composable of the app. Sets up navigation and wires screens together.
 *
 * Plays the role that three separate pieces played in the original View-based
 * implementation:
 *
 * - **`activity_main.xml`** hosted a `NavHostFragment` that acted as the
 *   container where the current destination was swapped in.
 * - **`res/navigation/nav_graph.xml`** declared the destinations (list,
 *   detail), their arguments, and the action between them.
 * - **Safe Args** generated `ListFragmentDirections` /
 *   `DetailFragmentArgs` classes to pass the flower name type-safely.
 *
 * In Compose all three collapse into a single `NavHost { ... }` call inside
 * a regular Kotlin function. Destinations are `@Composable` lambdas keyed by
 * a string route, and arguments travel through the route itself
 * (`"detail/{flower}"`), extracted at the destination from
 * `backStackEntry.arguments`. The `Uri.encode` call replaces what Safe Args
 * used to do automatically — escaping characters like spaces so that a
 * flower name like `"Flower 14"` survives as a path segment. Navigation
 * Compose decodes the value on the way out.
 *
 * The [Datasource] is instantiated once and wrapped in [remember] so it
 * survives recompositions, similar to how the old `ListFragment` created it
 * once in `onCreateView`.
 *
 * ### About route strings vs type-safe routes
 * This sample uses the classic string-based routing API: a path template
 * with a placeholder (`"detail/{flower}"`) and a manual [Uri.encode] call on
 * the value before `navigate(...)`. Since Navigation 2.8 there is also a
 * type-safe alternative based on Kotlin Serialization — you define a
 * `@Serializable data class DetailRoute(val flower: String)` and the library
 * handles the encoding, decoding and argument declaration for you. We keep
 * the string-based style here because it is what the course materials show.
 * Reference:
 * https://developer.android.com/guide/navigation/design/type-safety
 */
@Composable
private fun RecyclerSampleApp(modifier: Modifier = Modifier) {
    val navController = rememberNavController()
    val context = LocalContext.current
    val flowers = remember { Datasource(context).getFlowerList().asList() }

    NavHost(
        navController = navController,
        startDestination = Routes.LIST,
        modifier = modifier
    ) {
        composable(Routes.LIST) {
            FlowerList(
                flowers = flowers,
                onFlowerClick = { flower ->
                    // [Uri.encode] escapes characters like spaces so that a flower
                    // name such as "Flower 14" survives as a path segment
                    val encoded = Uri.encode(flower.name)
                    navController.navigate(Routes.detail(encoded))
                }
            )
        }
        composable(
            route = Routes.DETAIL,
            arguments = listOf(navArgument("flower") { type = NavType.StringType })
        ) { backStackEntry ->
            // Note the asymmetry with `Uri.encode` above: there is no matching
            // `Uri.decode` here because Navigation Compose decodes path arguments
            // automatically when it populates `backStackEntry.arguments`.
            // The string we get is already the original, un-escaped flower name
            val flowerName = backStackEntry.arguments?.getString("flower").orEmpty()
            DetailScreen(flowerName = flowerName)
        }
    }
}
