RecyclerSimple
==============

Contains the finished code of Google's Simple RecyclerView sample app,
with modifications. This version of the app has been fully migrated to
Jetpack Compose: the list is implemented with `LazyColumn`, navigation
uses the Navigation Compose library, and the UI lives entirely in
composables hosted by a single `ComponentActivity`. Fragments, the
fragment-based Navigation component, XML layouts, and the `RecyclerView`
adapter are no longer used.

The original code can be found in the main branch of the
[views-widgets-samples](https://github.com/android/views-widgets-samples)
repository as of commit f22069a, inside the RecyclerViewSimple directory.

For an overview of `LazyColumn` and Compose-based lists, consult Google's
"[Lists and grids](https://developer.android.com/develop/ui/compose/lists)"
guide. For navigation between composable screens, see
"[Navigation with Compose](https://developer.android.com/develop/ui/compose/navigation)".
